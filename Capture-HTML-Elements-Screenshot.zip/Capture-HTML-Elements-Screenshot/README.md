# JavaScript-screenshot
JavaScript implementation of a screenshot with `html2canvas.js` and `canvas2image.js`

##  [Blog address](https://blog.csdn.net/caomage/article/details/81168201)
